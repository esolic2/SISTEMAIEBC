<?php
require_once "Controladores/plantillaC.php";
require_once "Controladores/usuariosC.php";
require_once "Modelos/usuariosM.php";

$plantilla = new Plantilla();
$plantilla -> LlamarPlantilla();