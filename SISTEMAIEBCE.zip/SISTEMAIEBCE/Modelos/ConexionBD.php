<?php

class ConexionBD{

	public function cBD(){
		$bd = new PDO("mysql:host=localhost:8080;dbname=bdiebc","root","");
		$bd -> exec("set names utf8");

		return $bd;
}
}