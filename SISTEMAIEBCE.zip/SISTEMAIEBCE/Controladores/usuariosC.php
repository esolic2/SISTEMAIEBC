<?php

class UsuariosC{

	public function IniciarSesionC(){
		if(isset($_POST["carne"])){
			if(preg_match('/^[a-zA-Z0-9]+$/', $_POST["carne"]) && preg_match('/^[a-zA-Z0-9.-]+$/', $_POST["clave"])){
				$tablaBD = "usuarios";
				$datosC = array("carne"=>$_POST["carne"], "clave"=>$_POST["clave"]);
				$resultado = UsuariosM::IniciarSesionM($tablaBD, $datosC);

				if($resultado["carne"] == $_POST["carne"] && $resultado["clave"] == $_POST["clave"]){
					$_SESSION["Ingresar"] == true;
				}
			}
		}
	}
}